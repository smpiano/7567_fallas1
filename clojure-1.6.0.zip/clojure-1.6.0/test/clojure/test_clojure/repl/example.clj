(ns clojure.test-clojure.repl.example)

;; sample namespace for repl tests, don't add anything here
(defn foo [])
(defn bar [])
